package main_test

import (
	"testing"
)

func TestDummy(t *testing.T) {
	t.Log("all good in the hood!")
}
